const express = require('express');
const { MongoClient } = require('mongodb');

const app = express();
const PORT = process.env.PORT || 5500;
const MONGODB_URI = 'mongodb://localhost:27017'; // Update with your MongoDB connection URI

app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

app.post('/submit-form', async (req, res) => {
    try {
        const client = new MongoClient(MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true });
        await client.connect();

        const db = client.db('eventTicketing'); // Update with your database name
        const collection = db.collection('events'); // Update collection name to 'events'

        const { name, email, event } = req.body;
        const result = await collection.insertOne({ _id_, email_1,});
        console.log('Form data inserted:', result.insertedId);

        await client.close();

        // Redirect to index.html with success message
        res.redirect('/index.html?success=true');
    } catch (err) { 
        console.error('Error submitting form:', err);
        res.status(500).send('Error submitting form');
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
