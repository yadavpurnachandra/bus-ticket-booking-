const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const Event = require('./public/simples'); // Assuming you have an Event model

const app = express();
const PORT = process.env.PORT || 3000;

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/eventTicketing', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => {
  console.log('MongoDB connected');
  // Manually insert data into MongoDB
  insertData();
})
.catch((err) => {
  console.error('Error connecting to MongoDB:', err);
  process.exit(1);
});

// Middleware
app.use(bodyParser.json());
app.use(cors({
  origin: 'http://127.0.0.1:3002' // Allow requests from this origin
}));

// Function to manually insert data into MongoDB
async function insertData() {
  try {
    const data = [
      { name: 'John Doe', email: 'john@example.com', selectedEvent: 'Event 1' },
      { name: 'Patrick Pan', email: 'patrickpan@gmail.com', selectedEvent: 'Event 2' },
      { name: 'Patrick Pan', email: 'royal@gmail.com', selectedEvent: 'Event 2' },
      // Add more data as needed
    ];
    await Event.insertMany(data);
    console.log('Data inserted successfully');
  } catch (err) {
    console.error('Error inserting data:', err);
  }
}

// POST endpoint to add a new event
app.post('/submit-form', async (req, res) => {
  try {
    const { name, email, event } = req.body; // Destructure the request body
    const newEvent = new Event({
      name,
      email,
      selectedEvent: event
    });
    await newEvent.save();
    console.log('Event added successfully');
    res.sendStatus(200);
  } catch (err) {
    //console.error('Error adding event:', err);
    res.status(500).send('Event Added');
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
