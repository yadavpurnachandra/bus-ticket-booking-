// models/event.js
const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  selectedEvent: { type: String, required: true },
  event1: { type: String },
  event2: { type: String }
});

const Event = mongoose.model('Event', eventSchema);

module.exports = Event;
